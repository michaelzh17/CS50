from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session, url_for
from flask_session import Session
from passlib.apps import custom_app_context as pwd_context
from tempfile import mkdtemp

from helpers import *

# configure application
app = Flask(__name__)

# ensure responses aren't cached
if app.config["DEBUG"]:
    @app.after_request
    def after_request(response):
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        response.headers["Expires"] = 0
        response.headers["Pragma"] = "no-cache"
        return response

# custom filter
app.jinja_env.filters["usd"] = usd

# configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")

@app.route("/")
@login_required
def index():
    # get stock and share information
    rows = db.execute("SELECT stock, SUM(shares) AS shares FROM 'transaction' WHERE userid=:user_id GROUP BY stock", user_id=session["user_id"])
    # get cash for user
    cash = db.execute("SELECT cash FROM users WHERE id = :user_id", user_id = session["user_id"])
    cash = cash[0]["cash"]
    # update stock price and value in record
    sum_cash = 0
    for row in rows:
        row['price'] = lookup(row['stock'])['price']
        row['stock_name'] = lookup(row['stock'])['name']
        sum_cash = sum_cash + row['price']*row['shares']
    return render_template("index.html", transaction = rows, cash_hand = cash, sum_cash = sum_cash+cash)

@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    """Buy shares of stock."""
    
    # if user reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        quote = lookup(request.form["stock"])
        
        # render apology if stock not valid or shares not positive
        if quote == None or int(request.form["shares"]) <= 0:
            return apology("stock not valid or shares not valid")
        else:
            # query cash from users table to check if user has enough cash to buy the shares of the stock
            cash = db.execute("SELECT cash FROM users WHERE id = :user_id", user_id = session["user_id"])
            cash = cash[0]["cash"]
            cash_check = cash - quote["price"] * int(request.form["shares"])
            
            # if cash is enough, insert transaction to table and update cash in user table
            if cash_check >= 0:
                # update buy record in transaction table
                db.execute("INSERT INTO 'transaction' (userid, stock, shares, price, cost) VALUES (:userid, :stock, :shares, :price, :cost)",
                userid=session["user_id"], stock=request.form["stock"].upper(), shares=request.form["shares"], price=quote["price"], cost=quote["price"]*int(request.form["shares"]))
                # update cash in users table
                db.execute("UPDATE users SET cash = :cash WHERE id = :userid", cash=cash_check, userid=session["user_id"])
                # run index()
                flash("Bought!")
                return redirect(url_for("index"))
                
            # if cash is not enough, render apology page
            else:
                return apology("not enough cash to buy")
    # else if user reached route via GET ( as by clicking a link or redirect)   
    else:
        return render_template("buy.html")
    

@app.route("/history")
@login_required
def history():
    """Show history of transactions."""
    
    history_trans = db.execute("SELECT stock, shares, price, date FROM 'transaction' WHERE userid=:user_id", user_id=session["user_id"])
    
    return render_template("history.html", transaction = history_trans)

@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in."""

    # forget any user_id
    session.clear()

    # if user reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username")

        # ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password")

        # query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username", username=request.form.get("username"))

        # ensure username exists and password is correct
        if len(rows) != 1 or not pwd_context.verify(request.form.get("password"), rows[0]["hash"]):
            return apology("invalid username and/or password")

        # remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # redirect user to home page
        return redirect(url_for("index"))

    # else if user reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")

@app.route("/logout")
def logout():
    """Log user out."""

    # forget any user_id
    session.clear()

    # redirect user to login form
    return redirect(url_for("login"))

@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    """Get stock quote."""
    
    # if user reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        quote = lookup(request.form["stock"])
        
        if quote == None:
            return render_template("apology.html")
        else:
            return render_template("quoted.html", stock_info=quote)
        
    
    # else if user reached route via GET ( as by clicking a link or redirect)   
    else:
        return render_template("quote.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user."""
    
    # forget any user id
    session.clear()
    
    # if user reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        
        rows = db.execute("SELECT username FROM users")
        
        user_row = {"username":request.form["username"]}
        # ensure username neither blank nor in db
        if request.form["username"] == "" or user_row in rows:
            return apology("user name you entered either blank or already exist")
        
        # ensure password not blank; password re-enter match
        if request.form["password"] == "" or request.form["password"] != request.form["repassword"]:
            return apology("password entered not match")
        
        hashword = pwd_context.encrypt(request.form["password"]) 
        db.execute("INSERT INTO users (username, hash) VALUES(:username, :hashword)", username=request.form["username"], hashword=hashword)
        
        login()
        # render index()
        flash("Registered!")
        return redirect(url_for("index"))
        
    # else if user reached route via GET ( as by clicking a link or redirect)
    else:
        return render_template("register.html")

@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock. Sold stock will be records in transaction with shares as negative number"""
    
    # if user reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        quote = lookup(request.form["stock"])
        
        # get stock list in user's portfolio
        rows = db.execute("SELECT stock FROM 'transaction' WHERE userid=:user_id GROUP BY stock", user_id=session["user_id"])

        # render apology if stock not in user's portfolio or shares not negative
        stock_row = {'stock':request.form["stock"].upper()}
        if stock_row not in rows or int(request.form["shares"]) <= 0:
            return apology("stock not in portfolio or shares not valid")
        else:
            # check if user has enough shares to sell
            shares_hold = db.execute("SELECT stock, SUM(shares) AS shares FROM 'transaction' WHERE userid = :user_id AND stock = :stock GROUP BY stock", user_id = session["user_id"], stock = request.form["stock"].upper())
            if int(shares_hold[0]["shares"]) < int(request.form["shares"]):
                return apology("not enough shares on portfolio to sell")
            cash = db.execute("SELECT cash FROM users WHERE id = :user_id", user_id = session["user_id"])
            cash = cash[0]["cash"]
            # update selling record to transaction table
            db.execute("INSERT INTO 'transaction' (userid, stock, shares, price, cost) VALUES (:userid, :stock, :shares, :price, :cost)",
            userid=session["user_id"], stock=request.form["stock"].upper(), shares=-int(request.form["shares"]), price=quote["price"], cost=quote["price"]*abs(int(request.form["shares"])))
            # update cash in users table
            db.execute("UPDATE users SET cash = :cash WHERE id = :userid", cash=cash + quote["price"] * int(request.form["shares"]), userid=session["user_id"])
            
            # run index function
            flash("Sold!")
            return redirect(url_for("index"))
        
    # else if user reached route via GET ( as by clicking a link or redirect)   
    else:
        return render_template("sell.html")
        
@app.route("/password_reset", methods=["GET", "POST"])
@login_required
def password_reset():
    
    # if user reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # ensure current password is right 
        current_password = db.execute("SELECT hash FROM users WHERE id = :user_id", user_id = session["user_id"])
        if not pwd_context.verify(request.form.get("oldpassword"), current_password[0]["hash"]):
            return apology("Current password not right")

        # ensure password not blank; password re-enter match
        if request.form["newpassword"] == "" or request.form["newpassword"] != request.form["re_newpassword"]:
            return apology("new password not match")

        new_hashword = pwd_context.encrypt(request.form["newpassword"]) 
        db.execute("UPDATE users SET hash=:hash_word WHERE id=:user_id", user_id=session["user_id"], hash_word=new_hashword)
        
        # render index()
        flash("Password reset!")
        return redirect(url_for("index"))

    # else if user reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("reset.html")
    
